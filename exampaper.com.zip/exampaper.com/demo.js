var a=1;
var b=2;
var c=a+b;
prompt('hello'+c)